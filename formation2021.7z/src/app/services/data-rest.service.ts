import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { catchError, map, retry, tap } from 'rxjs/operators';
import { Client } from '../model/client';
import { DataService } from './data.service';

const API_URL = 'https://banque.azurewebsites.net/api';
const JWTOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IjIiLCJuYmYiOjE2MTg0ODk1MjgsImV4cCI6MTYxOTA5NDMyOCwiaWF0IjoxNjE4NDg5NTI4fQ.YyYyOJ9LgWfVDL-dPTfMXLHb0Of3QKm-wRMG9WmLQPg';

@Injectable()
export class DataRestService implements DataService {

  constructor(
    private http: HttpClient
  ) { }

  /**
   * Envoyer les données en POST
   * @param client 
   */
  createClient(client: Client): Observable<void> {
    return this.http
      .post<void>(`${API_URL}/clients/auth`, client, {
        headers : {
          'Authorization' : `Bearer ${JWTOKEN}`
        }
      })
  }

  /**
   * Acceder à la liste des clients
   * @returns liste des clients
   */
  readClients(): Promise<Client[]> {

    let clients = [];

    // Promise
    let attente: Promise<Client[]> = new Promise((resolve, reject) => {

      this.http
        .get<Client[]>(`${API_URL}/clients`)
        .subscribe(data => {
          console.log(data);
          resolve(data);
        })
        /*
        .pipe(
          catchError( err => {
            reject(err);
            return of(null);
          })
        )
        */

    });

    return attente;
  }

  /**
   * Acceder à un client depuis un Observable
   * @param id 
   * @returns information client
   */
  readClient(id: number): Observable<Client> {

    return this.http
      .get<Client>(`${API_URL}/clients/${id}`)

      /**
      * RXJS : https://www.learnrxjs.io/learn-rxjs/operators
      */
      .pipe(
        map(cli => ({
          ...cli,
          prenom: cli.prenom.charAt(0) + '.',
          email: `${cli.prenom.toLowerCase()}.${cli.nom.toLowerCase()}@eni.fr`
        })),
        tap(cli => {
          console.log(cli);
        }),
        retry(2)
      );

  }

}
