import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { AuthToken } from '../model/auth-token';

const AUTH_URL = "https://banque.azurewebsites.net/api/auth";

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  token: AuthToken = null;

  //{
  //"id": 2,
  // "username": "formation",
  //"password": null,
  //"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IjIiLCJuYmYiOjE2MTg0ODk4NDcsImV4cCI6MTYxOTA5NDY0NywiaWF0IjoxNjE4NDg5ODQ3fQ.W9e8whqHd-JKCs39c_ag4pPU8HrLmWjwncaHmdS9rvk"
  // } 

  constructor(
    private http: HttpClient
  ) { }


  // ====> Possibilité d'utiliser le localStorage

  login(user: AuthToken): Observable<AuthToken> {
    return this.http.post<AuthToken>(AUTH_URL, user)
      .pipe(
        tap(jwt => {
          if (jwt?.token) this.token = jwt;
        })
      )
  }

  logout(): void {
    this.token = null;
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return Boolean(this.token?.token);
  }

}
