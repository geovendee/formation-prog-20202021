import { Inject, Injectable } from "@angular/core";
import { ActivatedRoute, ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { Observable } from "rxjs";
import { Client } from "../model/client";
import { DataService } from "./data.service";

@Injectable({
    providedIn: 'root'
})
export class ClientResolver implements Resolve<Client> {

    constructor(
        @Inject('DataService') private dataService: DataService
    ){ }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Client> {
        return this.dataService.readClient(Number(route.params['id']));
    }

}
