import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { Client } from "../model/client";
import { DataService } from "./data.service";

@Injectable()
export class DataLocalService implements DataService {

    static ID: number = 10;

    private clients: Client[] = [
        {
            "id": 2, "nom": "leblanc", "prenom": "just"
        },
        {
            "id": 3, "nom": "durand", "prenom": "christian"
        }
    ];

    constructor() { 
        this.load();
    }

    /**
     * Charger la liste depuis local storage
     */
    private load() {
        this.clients = JSON.parse(localStorage.getItem('data'));
    }

    /**
     * Sauvegarder dans le local storage
     */
    private save() {
        localStorage.setItem('data', JSON.stringify(this.clients) || '[]')
    }

    /**
     * Création d'un nouveau client
     * @param client 
     */
    createClientSync(client: Client): void {
        
        /*
        if (isNaN(client.id)) {
            client.id = DataLocalService.ID++;
        }
        */

        /* get max id ou 0 */

        /* 1er methode (sort + compare) */
        client.id = this.clients
            .map(cli => cli.id)
            .sort( (id1,id2) => id2 - id1)
            [0] || 0
            +1;
        /* 2nd methode (Math.max) */
        //client.id = this.clients?.length ? Math.max(...this.clients.map( cli => cli.id)) +1 : 1;
            
        this.clients.push(client)

        this.save();
    }

    /**
     * Liste des clients
     * @returns liste des clients
     */
    readClientsSync(): Client[] {
        return this.clients;
    }

    /**
     * 1 Client
     * @param id 
     * @returns un client
     */
    readClientSync(id: number): Client {

        return this.clients.find( cli => cli.id === id );

    }

    createClient(client:Client): Observable<void> {
        return of(this.createClientSync(client));
    }
    readClients(): Promise<Client[]> {
        return Promise.resolve(this.readClientsSync());
    }
    readClient(id:number): Observable<Client>{
        return of(this.readClientSync(id));

    }

}