import { Observable } from "rxjs";
import { Client } from "../model/client";

export interface DataService {

    createClient(client:Client): Observable<void>;
    readClients(): Promise<Client[]>;
    readClient(id:number): Observable<Client>;
}