import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'prenom_nom',
  pure: true
})
export class NomClientPipe implements PipeTransform {

  transform(value: any): string {
    return value.prenom + ' ' + value.nom.toUpperCase();
  }

}
