import { Client } from '../model/client';
import { NomClientPipe } from './nom-client.pipe';

describe('NomClientPipe', () => {
  it('create an instance', () => {
    const pipe = new NomClientPipe();
    expect(pipe).toBeTruthy();
  });
  it('generate full name label', () => {
    const pipe = new NomClientPipe();
    const client = new Client({nom: 'titi', prenom: 'toto'});
    const result = pipe.transform(client);
    expect(result).toBe('toto TITI');
  });
});
