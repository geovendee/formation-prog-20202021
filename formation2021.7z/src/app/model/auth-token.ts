export interface AuthToken {
    id?: number;
    username: string;
    password?: string;
    token?: string;
}