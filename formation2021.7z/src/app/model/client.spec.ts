import { Client } from "./client";

describe('Classe métier Client', () => {

    let cli:Client;

    beforeEach( () => {
        cli = new Client();
    })

    it('doit créé un objet Client', () => {
        expect(cli).toBeTruthy();
    });

    // xit - fir : ignorer - executer seul

    it('doit contenir une liste vide de comptes', () => {

        expect(cli.comptes).toBeTruthy();
        expect(cli.comptes.length).toBe(0);

    });

});