import { Compte } from './compte';

export class Client {

    id:number = NaN;
    
    /*
    private _nom: string;
    private _prenom: string;
    */

    nom: string;
    prenom: string;
    email?:string = '';

    public comptes?: Compte[] = [];

    constructor(params?: any) {
        this.id = params?.id || NaN;
        this.nom = params?.nom || '';
        this.prenom = params?.prenom || '';
    }

    /*
    get nom(): string {
        return this._nom.toUpperCase();
    }

    get prenom(): string {
        return this._prenom;
    }

    set nom(value: string) {
        this._nom = value?.toUpperCase() || '';
    }

    set prenom(value: string) {
        this._prenom = value;
    }
    */

    toString() {
        return `${this.prenom} ${this.nom}`;
    }
}