export class Compte {

    numero?: string;
    intitule?: string;
    operation?: any [];

}