import { LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { RootComponent } from './components/root/root.component';
import { DemoComponent } from './components/demo/demo.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ListClientsComponent } from './components/list-clients/list-clients.component';

import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { NomClientPipe } from './pipes/nom-client.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {MatButtonModule} from '@angular/material/button';

import {MatIconModule} from '@angular/material/icon';
import { AppMaterialModule } from './app-material.module';
import { ClientFormComponent } from './components/client-form/client-form.component';
import { ClientReactiveFormComponent } from './components/client-reactive-form/client-reactive-form.component';
import { DataLocalService } from './services/data-local.service';
import { ClientDetailsComponent } from './components/client-details/client-details.component';
import { DataRestService } from './services/data-rest.service';
import { HttpClientModule } from '@angular/common/http';
import { AuthFormComponent } from './webcomponents/auth-form/auth-form.component';
import { environment } from 'src/environments/environment';

registerLocaleData(localeFr, "fr-FR");

@NgModule({
  declarations: [
    RootComponent,
    DemoComponent,
    ListClientsComponent,
    NomClientPipe,
    ClientFormComponent,
    ClientReactiveFormComponent,
    ClientDetailsComponent,
    AuthFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    AppMaterialModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    { provide: LOCALE_ID, useValue: "fr-FR" },

    /* Nommer le service 'DataService' qui pointe sur DataLocalService */
    { provide: 'DataService', useClass:environment.dataServiceProvider}
  ],
  bootstrap: [RootComponent]
})
export class AppModule { }
