import { Component, Inject, OnInit } from '@angular/core';
import { Client } from 'src/app/model/client';
import { DataLocalService } from 'src/app/services/data-local.service';

@Component({
  selector: 'app-client-form',
  templateUrl: './client-form.component.html',
  styleUrls: ['./client-form.component.css']
})
export class ClientFormComponent implements OnInit {


  client:Client = new Client();

  constructor(
    @Inject('DataService')
    private dataService : DataLocalService
  ) { }

  ngOnInit(): void {

  }
  
  effacer():void {
    this.client = new Client();
  }

  onSubmit():void {
    this.dataService.createClientSync(this.client);
    console.log(`Création d'un nouveau client : ${this.client}`);
    this.client = new Client();
  }

}
