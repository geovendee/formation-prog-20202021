import { Component } from '@angular/core';
import { AuthToken } from 'src/app/model/auth-token';
import { AuthGuard } from 'src/app/services/auth.guard';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css']
})
export class RootComponent {


  title = 'formation2021';

  jwtoken: AuthToken = {
    username: '',

  };

  showAuthForm: boolean = false;

  constructor(private authService: AuthGuard) {
    this.supprimerToken();
  }


  enregistrerToken(token: AuthToken): void {
    this.jwtoken = token;
    this.showAuthForm = false;
  }

  supprimerToken():void {
    this.jwtoken = {username: this.jwtoken.username};
    this.authService.logout();
    this.showAuthForm = true;
  }


}
