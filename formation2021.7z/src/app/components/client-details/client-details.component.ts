import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Client } from 'src/app/model/client';
import { DataLocalService } from 'src/app/services/data-local.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-client-details',
  templateUrl: './client-details.component.html',
  styleUrls: ['./client-details.component.css']
})
export class ClientDetailsComponent implements OnInit {

  client: Client = null;
  /*
  clientNom: string = '';
  clientPrenom : string = '';
  */

  constructor( 
    @Inject('DataService')
    private dataService: DataService,
    private route:ActivatedRoute
  ) { }

  ngOnInit(): void {

    /*
   const id = this.route.snapshot.params['id'];

   this.dataService
    .readClient(id)
    .subscribe(data => this.client = data);
    */

  this.client = this.route.snapshot.data['client'];

   /*
   this.clientNom = client.nom;
   this.clientPrenom = client.prenom;
   */


  }

}
