import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Client } from 'src/app/model/client';
import { DataRestService } from 'src/app/services/data-rest.service';

/*
import {DATA } from '../../data';
*/

@Component({
  selector: 'app-list-clients',
  templateUrl: './list-clients.component.html',
  styleUrls: ['./list-clients.component.css']
})
export class ListClientsComponent implements OnInit {

  clients: any[] = [];

  constructor(
    @Inject('DataService')
    private dataService: DataRestService,
    private router: Router
  ) { }

  ngOnInit(): void {

    // S'inscrire à la reponse (Promise)
    let attente: Promise<Client[]> = this.dataService.readClients();
    attente
      .then( data => this.clients = data )
      .catch()
  }

  onClick():void {
    this.router.navigate(['client/:id'])
  }

}
