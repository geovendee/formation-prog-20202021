import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',                 // <app-demo></app-demo>
  // --> selector: '#app-demo',  
  templateUrl: './demo.component.html',
  /* 
  template: `
    <h1>Ma Banque</h1>
    <p>Composant Démo</p>
  `, 
  */
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {


  message: string;
  messageContent: string;
  uneClasse: string;
  maDate = new Date();

  constructor() { }

  ngOnInit(): void {

    this.message = "1er data binding"
    this.messageContent = "Contenu binding"
    this.uneClasse = "blueStyle"

  }

  clickTexte() {
    this.message += ", click";
  }

}
