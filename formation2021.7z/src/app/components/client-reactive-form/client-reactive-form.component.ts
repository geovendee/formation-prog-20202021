import { Component, Inject, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Client } from 'src/app/model/client';
import { DataLocalService } from 'src/app/services/data-local.service';
import { DataRestService } from 'src/app/services/data-rest.service';

@Component({
  selector: 'app-client-reactive-form',
  templateUrl: './client-reactive-form.component.html',
  styleUrls: ['./client-reactive-form.component.css']
})
export class ClientReactiveFormComponent implements OnInit {

  nomInput = new FormControl('Delsinne', [Validators.required]);

  comptesFormArray =  new FormArray([
    /*{numero:...,intitule:...}*/
    /*new FormGroup({
      numero: new FormControl('12345678'),
      intitule: new FormControl('Livret A')
    }),
    new FormGroup({
      numero: new FormControl('00000000'),
      intitule: new FormControl('New')
    }),
    new FormGroup({
      numero: new FormControl('98765432'),
      intitule: new FormControl('PEL')
    })*/
  ])

  clientForm = new FormGroup({
    'nom': this.nomInput,
    'prenom' : new FormControl(''),
    'comptes': this.comptesFormArray
  });

  constructor(
    @Inject('DataService')
    private dataService : DataRestService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.clientForm.patchValue(new Client());
  }

  addCompte(): void {
    this.comptesFormArray.push(
      new FormGroup({
        numero: new FormControl,
        intitule: new FormControl
      })
    )
  }

  removeCompte(index:number):void {
    this.comptesFormArray.removeAt(index);
  }

  enregistrer() {
    console.log(this.clientForm.value);
    this.dataService.createClient(this.clientForm.value)
      .subscribe( () => {this.router.navigate(['/clients'])});

  }

}
