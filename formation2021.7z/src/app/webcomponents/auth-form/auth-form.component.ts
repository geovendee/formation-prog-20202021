import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { AuthToken } from 'src/app/model/auth-token';
import { AuthGuard } from 'src/app/services/auth.guard';

@Component({
  selector: 'app-auth-form',
  templateUrl: './auth-form.component.html',
  styleUrls: ['./auth-form.component.css']
})
export class AuthFormComponent implements OnInit {

  @Input()
  token: AuthToken;

  @Output()
  connected: EventEmitter<AuthToken> = new EventEmitter<AuthToken>();

  constructor(
    private authService : AuthGuard
  ) { }

  ngOnInit(): void {

  }

  onSubmit():void {

    // S'abonner
    this.authService.login(this.token)
      .subscribe( jwt => this.connected.emit(jwt)) // en repons
    this.connected.emit(null);
  }

}
