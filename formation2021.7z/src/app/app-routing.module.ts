import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClientDetailsComponent } from './components/client-details/client-details.component';
import { ClientReactiveFormComponent } from './components/client-reactive-form/client-reactive-form.component';
import { DemoComponent } from './components/demo/demo.component';
import { ListClientsComponent } from './components/list-clients/list-clients.component';
import { AuthGuard } from './services/auth.guard';
import { ClientResolver } from './services/client.resolver';

const routes: Routes = [{
  path: '', redirectTo: '/clients', pathMatch: 'full'
},{
  path: 'demo', component: DemoComponent
},{
  path: 'clients', component: ListClientsComponent
},{
  path: 'client/form', component: ClientReactiveFormComponent, canActivate: [AuthGuard]
},{
  path: 'clients/:id', component: ClientDetailsComponent,
    // pre-charger la reponse serveur
    resolve: {
      client: ClientResolver
    }
}, {
  path: '**', redirectTo: '/clients'
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
