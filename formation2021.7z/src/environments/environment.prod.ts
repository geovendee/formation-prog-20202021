import { DataRestService } from "src/app/services/data-rest.service";

export const environment = {
  production: true,
  dataServiceProvider: DataRestService
};
